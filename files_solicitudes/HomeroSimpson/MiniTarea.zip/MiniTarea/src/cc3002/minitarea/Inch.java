package cc3002.minitarea;

import java.util.Objects;

public class Inch extends AbstractMetric {
    /**
     * the corresponding factor to get 1 Inch from 1 Meter
     */
    private static final double InchToMeter = 0.0254;

    /**
     * @param i value of the DistanceMetric
     */
    public Inch(double i) {
        super(i, InchToMeter);
    }

    /**
     * The sum of an Inch value with any DistanceMetric value
     * @return An Inch object with the sum as the value
     */
    @Override
    public DistanceMetric add(DistanceMetric distance) {
        return new Inch(this.addInItself(this, distance));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Inch inch = (Inch) o;
        return Double.compare(inch.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
