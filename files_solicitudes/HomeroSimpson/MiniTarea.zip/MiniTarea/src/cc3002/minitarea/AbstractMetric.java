package cc3002.minitarea;

/**
 * Abstract class that implements distanceMetric
 */
public abstract class AbstractMetric implements DistanceMetric {

    protected final double value;
    protected final double toMeter;

    /**
     * AbstractMetric constructor
     * @param value any value for the DistanceMetric
     * @param toMeter the corresponding factor to get 1 DistanceMetric
     */
    protected AbstractMetric(double value, double toMeter) {
        this.value = value;
        this.toMeter = toMeter;
    }

    /**
     * @return the value of the DistanceMetric
     */
    @Override
    public double getValue(){
        return this.value;
    }
    /**
     * @return the factor that you multiply 1 meter to get 1 DistanceMetric
     */
    @Override
    public double getToMeter() {
        return this.toMeter;
    }
    /**
     * Converts any distance to the corresponding Meter distance
     * @return A Meter object with the
     */
    public Meter convertToMeters(DistanceMetric v) {
        return new Meter(v.getToMeter()*v.getValue());
    }

    /**
     * Converts a meter distance to the corresponding DistanceMetric value
     * @return A double with the correspoding value
     */
    public double convertMetersToItself(Meter m){
        return 1/this.getToMeter()*m.getValue();
    }

    /**
     * Sum two DistanceMetric values
     * @return A DistanceMetric object with the sum as the value. It uses the first's DistanceMetric format.
     */
    public abstract DistanceMetric add(DistanceMetric distance);

    /**
     * Add two DistanceMetric
     * @return the value of the sum in the first's DistanceMetric format
     */
    public double addInItself(DistanceMetric dist1, DistanceMetric dist2){
        return this.convertMetersToItself(this.addInMeters(dist1, dist2));
    }
    /**
     * Add two DistanceMetric in Meter format
     * @return Meter object with the corresponding value
     */
    public Meter addInMeters(DistanceMetric v1, DistanceMetric v2){
        return new Meter(convertToMeters(v1).getValue() + convertToMeters(v2).getValue());
    }

}

