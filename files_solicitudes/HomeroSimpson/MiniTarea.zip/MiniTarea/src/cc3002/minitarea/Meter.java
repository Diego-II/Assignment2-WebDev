package cc3002.minitarea;

import java.util.Objects;

public class Meter extends AbstractMetric{
    /**
     * the corresponding factor to get 1 Meter from 1 Meter
     */
    private static final double MeterToMeter = 1;

    /**
     * @param i value of the DistanceMetric
     */
    public Meter(double i) {
        super(i, MeterToMeter);
    }

    /**
     * The sum of a Meter value with any DistanceMetric value
     * @return A Meter object with the sum as the value
     */
    @Override
    public DistanceMetric add(DistanceMetric distance) {
        return new Meter(this.addInItself(this, distance));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Meter meter = (Meter) o;
        return Double.compare(meter.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
