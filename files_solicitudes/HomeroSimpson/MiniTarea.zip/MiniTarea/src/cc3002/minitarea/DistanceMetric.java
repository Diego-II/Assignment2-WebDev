package cc3002.minitarea;

/**
 * Interface for any distance metric (meter, inches, bananas)
 */
public interface DistanceMetric {

    /**
     * @param distance any DistanceMetric that we want to add
     * @return the corresponding DistanceMetric
     */
    DistanceMetric add(DistanceMetric distance);

    /**
     * @return the value of the DistanceMetric
     */
    double getValue();

    /**
     * @return the factor that you multiply 1 meter to get 1 DistanceMetric
     */
    double getToMeter();
}
