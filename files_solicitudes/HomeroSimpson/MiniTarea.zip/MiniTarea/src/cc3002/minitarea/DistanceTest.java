package cc3002.minitarea;

import org.junit.Test;

import static org.junit.Assert.*;

public class DistanceTest {
    public double epsilon = 0.01;


    /**
     * Constructor Test
     */
    @Test
    public void constructorTest(){
        DistanceMetric meters = new Meter(1);
        DistanceMetric inches = new Inch(39);
        assertEquals(inches, new Inch(39));
        assertEquals(meters, new Meter(1));
        assertNotEquals(inches, null);
        assertNotEquals(meters, null);
        assertNotEquals(inches, new Inch(38));
        assertNotEquals(meters, new Meter(42));
        assertNotEquals(inches, new Meter(39));
        assertNotEquals(meters, new Inch(1));
    }

    /**
     * Add Inch to Meter Test
     */
    @Test
    public void addInchToMeterTest(){
        DistanceMetric meters = new Meter(1);
        DistanceMetric inches = new Inch(39);
        DistanceMetric expectedMeters = new Meter(1.9906);
        assertEquals(expectedMeters.getValue(), meters.add(inches).getValue(), epsilon);
        assertNotEquals(expectedMeters.getValue(), inches.add(meters).getValue(), epsilon);
    }

    /**
     * Add Meter to Inch Test
     */
    @Test
    public void addMeterToInchTest(){
        DistanceMetric inches = new Inch(10);
        DistanceMetric meters = new Meter(2);
        DistanceMetric expectedInches = new Inch(88.74);
        assertEquals(expectedInches.getValue(), inches.add(meters).getValue(), epsilon);
        assertNotEquals(expectedInches.getValue(), meters.add(inches).getValue(), epsilon);
    }

    /**
     * Add Meter to Meter Test
     */
    @Test
    public void addMeterToMeterTest(){
        DistanceMetric meters = new Meter(5);
        DistanceMetric meters2 = new Meter(3);
        DistanceMetric expectedMeters = new Meter(8);
        assertEquals(expectedMeters.getValue(), meters.add(meters2).getValue(), epsilon);
        assertEquals(expectedMeters.getValue(), meters2.add(meters).getValue(), epsilon);
    }

    /**
     * Add Inch to Inch Test
     */
    @Test
    public void addInchToInchTest(){
        DistanceMetric inches = new Inch(3);
        DistanceMetric inches2 = new Inch(10);
        DistanceMetric expectedInches = new Inch(13);
        assertEquals(expectedInches.getValue(), inches.add(inches2).getValue(), epsilon);
        assertEquals(expectedInches.getValue(), inches2.add(inches).getValue(), epsilon);
    }

}
