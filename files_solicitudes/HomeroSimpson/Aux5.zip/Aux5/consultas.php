<?php
/*
Implementar:
1. Preparar SQL para insertar orden: INSERT INTO ordenes (nombre, telefono, direccion, comuna, masa, comentario) VALUES (v1,v2,v3,v4,v5,v6)". Usar sprintf y limpiar los campos con la función limpiar(texto);
2. Ejecutar SQL
3. Recuperar el id de la inserción anterior
4. Preparar SQL para insertar los ingredientes: INSERT INTO ordenes_ingredientes (id_orden, id_ingrediente) VALUES (id1, id2).
x6. retornar true si todo salió bien, false si surgió un problema.
*/
function saveOrder($db, $nombre, $telefono, $direccion, $comuna, $masa, $ingredientes, $comentarios,$costo){	
	return false;
}
function limpiar($db, $str){
	return htmlspecialchars($db->real_escape_string($str));
}

function getComunas($db){
	$sql = "SELECT id, nombre FROM comunas";
	$result = $db->query($sql);
	$res = array();
	while ($row = $result->fetch_assoc()) {
		$res[] = $row;
	}
	return $res;
}

function getOrders($db){
	$sql = "SELECT ordenes.id, ordenes.nombre, ordenes.direccion, comunas.nombre as comuna_nombre, ordenes.masa
	FROM ordenes, comunas
	WHERE ordenes.comuna = comunas.id";
	$result = $db->query($sql);
	$res = array();
	while ($row = $result->fetch_assoc()) {
		$res[] = $row;
	}
	return $res;
}
?>
